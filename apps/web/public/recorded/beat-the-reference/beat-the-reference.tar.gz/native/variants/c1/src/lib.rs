//! Native variant `c1` (cryptificate-native codegen v1).
//!
//! Program identity: sha256:fe4c13c18bed532a0e67f93f45e95aef7ac29527df81f00a28e0a570542ef1c4
//! Field: GF(2^8), width 4; 12 additions, 4 multiplications.
//!
//! `mix_batch(input, output, column_count)` computes `y = M x` for each of
//! `column_count` columns: 4 bytes per column in row order (byte r is row r), GF(2^8) with polynomial 0x11B.
//! `input` and `output` must not overlap.

#![allow(unused_imports, unused_variables)]

use cryptificate_kernels::gf256::{add, mul, xtime};

const WIDTH: usize = 4;

#[no_mangle]
pub extern "C" fn mix_batch(input: *const u8, output: *mut u8, column_count: usize) {
    let Some(len) = column_count.checked_mul(WIDTH) else {
        return;
    };
    if len == 0 || input.is_null() || output.is_null() {
        return;
    }
    // SAFETY: the caller passes `column_count` columns in each buffer, aligned
    // for `u8`, and the buffers do not overlap.
    let (src, dst) = unsafe {
        (
            core::slice::from_raw_parts(input.cast::<u8>(), len),
            core::slice::from_raw_parts_mut(output.cast::<u8>(), len),
        )
    };
    for (x, y) in src.chunks_exact(WIDTH).zip(dst.chunks_exact_mut(WIDTH)) {
        let r0 = x[0];
        let r1 = x[1];
        let r2 = x[2];
        let r3 = x[3];
        let r4 = add(r0, r1);
        let r5 = xtime(r4);
        let r6 = add(r2, r3);
        let r7 = add(r1, r6);
        let r8 = add(r5, r7);
        let r9 = add(r1, r2);
        let r10 = xtime(r9);
        let r11 = add(r0, r6);
        let r12 = add(r10, r11);
        let r13 = xtime(r6);
        let r14 = add(r3, r4);
        let r15 = add(r13, r14);
        let r16 = add(r0, r3);
        let r17 = xtime(r16);
        let r18 = add(r2, r4);
        let r19 = add(r17, r18);
        y[0] = r8;
        y[1] = r12;
        y[2] = r15;
        y[3] = r19;
    }
}
