//! Native variant `baseline-direct` (cryptificate-native codegen v1).
//!
//! Program identity: sha256:0c19a4ef8d1eb47bae2ece74a55cb6b6529913234da6e7eec0a3a81906e1a767
//! Field: GF(2^8), width 4; 16 additions, 4 multiplications.
//!
//! `mix_batch(input, output, column_count)` computes `y = M x` for each of
//! `column_count` columns: 4 bytes per column in row order (byte r is row r), GF(2^8) with polynomial 0x11B.
//! `input` and `output` must not overlap.

#![allow(unused_imports, unused_variables)]

use cryptificate_kernels::gf256::{add, mul, xtime};

const WIDTH: usize = 4;

#[no_mangle]
pub extern "C" fn mix_batch(input: *const u8, output: *mut u8, column_count: usize) {
    let Some(len) = column_count.checked_mul(WIDTH) else {
        return;
    };
    if len == 0 || input.is_null() || output.is_null() {
        return;
    }
    // SAFETY: the caller passes `column_count` columns in each buffer, aligned
    // for `u8`, and the buffers do not overlap.
    let (src, dst) = unsafe {
        (
            core::slice::from_raw_parts(input.cast::<u8>(), len),
            core::slice::from_raw_parts_mut(output.cast::<u8>(), len),
        )
    };
    for (x, y) in src.chunks_exact(WIDTH).zip(dst.chunks_exact_mut(WIDTH)) {
        let r0 = x[0];
        let r1 = x[1];
        let r2 = x[2];
        let r3 = x[3];
        let r4 = xtime(r0);
        let r5 = xtime(r1);
        let r6 = xtime(r2);
        let r7 = xtime(r3);
        let r8 = add(r4, r1);
        let r9 = add(r8, r5);
        let r10 = add(r9, r2);
        let r11 = add(r10, r3);
        let r12 = add(r0, r5);
        let r13 = add(r12, r2);
        let r14 = add(r13, r6);
        let r15 = add(r14, r3);
        let r16 = add(r0, r1);
        let r17 = add(r16, r6);
        let r18 = add(r17, r3);
        let r19 = add(r18, r7);
        let r20 = add(r0, r4);
        let r21 = add(r20, r1);
        let r22 = add(r21, r2);
        let r23 = add(r22, r7);
        y[0] = r11;
        y[1] = r15;
        y[2] = r19;
        y[3] = r23;
    }
}
