//! Native variant `user` (cryptificate-native codegen v1).
//!
//! Program identity: sha256:510eb4d3ef8b0b609a6b7b154de0804ddfd1284703589918d306015fa2077372
//! Field: BN254 Fr, width 3; 5 additions, 0 multiplications.
//!
//! `mix_batch(input, output, column_count)` computes `y = M x` for each of
//! `column_count` columns: 3 BN254 Fr values per column (96 bytes), each in arkworks' in-memory form: four little-endian u64 limbs in Montgomery form; buffers aligned to at least 8 bytes.
//! `input` and `output` must not overlap.

#![allow(unused_imports, unused_variables)]

use cryptificate_kernels::bn254::{Fr, PrimeField};

const WIDTH: usize = 3;

#[no_mangle]
pub extern "C" fn mix_batch(input: *const u8, output: *mut u8, column_count: usize) {
    let Some(len) = column_count.checked_mul(WIDTH) else {
        return;
    };
    if len == 0 || input.is_null() || output.is_null() {
        return;
    }
    // SAFETY: the caller passes `column_count` columns in each buffer, aligned
    // for `Fr`, and the buffers do not overlap.
    let (src, dst) = unsafe {
        (
            core::slice::from_raw_parts(input.cast::<Fr>(), len),
            core::slice::from_raw_parts_mut(output.cast::<Fr>(), len),
        )
    };
    for (x, y) in src.chunks_exact(WIDTH).zip(dst.chunks_exact_mut(WIDTH)) {
        let r0 = x[0];
        let r1 = x[1];
        let r2 = x[2];
        let r3 = r0 + r1;
        let r4 = r3 + r2;
        let r5 = r4 + r0;
        let r6 = r4 + r1;
        let r7 = r4 + r2;
        y[0] = r5;
        y[1] = r6;
        y[2] = r7;
    }
}
