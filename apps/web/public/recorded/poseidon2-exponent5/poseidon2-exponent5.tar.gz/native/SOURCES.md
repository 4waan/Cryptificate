# Native sources

- `variants/<id>/`: the generated crate of each circuit (`src/lib.rs` is the crate root named `lib.rs` in its manifest).
- `workspace/Cargo.toml`: the build workspace; its members are `kernels` and `variants/<package>`.
- `kernels/`: the arithmetic primitives shared by every variant. `kernels/` matches the kernels the engine compiled into every variant (sha256:fec90fb7109560b69726e7a38ccd6bcb2b7a3f8266950d5eda040da1bc54fb68).
- `harness/`: the correctness and benchmark harness (`crates/native` of the checkout; its revision is the checker revision in `toolchain.json`).
- `correctness.json`, `measurements/`: raw results as the engine reported them.
