//! Building variant crates with cargo.
//!
//! The variants of a run are the members of one build workspace
//! (`<work>/Cargo.toml`), next to a copy of `cryptificate-kernels` and a copy
//! of the repository's lockfile, so every variant uses the same kernels and
//! the same pinned dependency versions. Each variant is still compiled on its own
//! (`cargo build -p <variant>`), with the same release profile and no
//! `RUSTFLAGS`. A shared `CARGO_TARGET_DIR` lets dependencies be reused
//! across variants and runs. The built library is copied into
//! `<work>/lib/` and loaded from there.

use std::fs;
use std::path::{Path, PathBuf};
use std::process::Command;
use std::time::Instant;

use anyhow::{bail, Context, Result};
use cryptificate_core::canonical::sha256_hex;

use crate::codegen::{workspace_manifest, VariantSource};
use crate::embedded;

/// Where and how variants are built.
#[derive(Clone, Debug)]
pub struct BuildOptions {
    /// Build workspace and copied libraries. [`crate::run_native`] uses a
    /// subdirectory `run-<digest of the variant packages>` of this.
    pub work_dir: PathBuf,
    /// Cargo target directory, shared across runs for dependency reuse.
    pub target_dir: PathBuf,
    /// Parallel jobs for cargo (`-j`).
    pub jobs: usize,
    /// The cargo executable.
    pub cargo: PathBuf,
    /// Pass `--offline` to cargo.
    pub offline: bool,
}

impl BuildOptions {
    /// Options with a work directory and the defaults for the rest: target
    /// directory from `CRYPTIFICATE_NATIVE_TARGET_DIR` or
    /// `<tmp>/cryptificate-native/target`, two jobs, cargo from `CARGO` or
    /// `PATH`.
    pub fn new(work_dir: impl Into<PathBuf>) -> Self {
        BuildOptions {
            work_dir: work_dir.into(),
            target_dir: default_target_dir(),
            jobs: 2,
            cargo: cargo_executable(),
            offline: false,
        }
    }
}

/// The default shared target directory.
pub fn default_target_dir() -> PathBuf {
    std::env::var_os("CRYPTIFICATE_NATIVE_TARGET_DIR")
        .map(PathBuf::from)
        .unwrap_or_else(|| {
            std::env::temp_dir()
                .join("cryptificate-native")
                .join("target")
        })
}

/// The cargo executable: `$CARGO` (set when running under cargo) or `cargo`.
pub fn cargo_executable() -> PathBuf {
    std::env::var_os("CARGO")
        .map(PathBuf::from)
        .unwrap_or_else(|| PathBuf::from("cargo"))
}

/// A compiled variant.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct BuiltVariant {
    pub id: String,
    pub package: String,
    /// The copied library that the harness loads.
    pub lib_path: PathBuf,
    /// `"sha256:<hex>"` of the library.
    pub lib_sha256: String,
    pub source_sha256: String,
    /// Wall-clock build time in milliseconds (includes dependencies on a
    /// cold target directory).
    pub build_ms: u64,
}

/// Writes `contents` to `path` unless it already holds exactly that, so
/// unchanged files keep their timestamps and cargo does not rebuild them.
fn write_if_changed(path: &Path, contents: &str) -> Result<()> {
    if fs::read_to_string(path).ok().as_deref() == Some(contents) {
        return Ok(());
    }
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent).with_context(|| format!("creating {}", parent.display()))?;
    }
    fs::write(path, contents).with_context(|| format!("writing {}", path.display()))
}

/// Creates or refreshes the build workspace for the given variants:
/// manifest, lockfile, the kernels crate and every variant crate (all
/// members must exist before cargo loads the workspace). Cargo trims the
/// lockfile to the packages in use, so it is rewritten only when the
/// embedded lockfile changed since it was last written (recorded in
/// `.lock-source`).
pub fn prepare_workspace(work_dir: &Path, variants: &[VariantSource]) -> Result<()> {
    let packages: Vec<&str> = variants.iter().map(|v| v.package.as_str()).collect();
    write_if_changed(&work_dir.join("Cargo.toml"), &workspace_manifest(&packages))?;
    let lock = work_dir.join("Cargo.lock");
    let marker = work_dir.join(".lock-source");
    let digest = sha256_hex(embedded::WORKSPACE_LOCK.as_bytes());
    if !lock.exists() || fs::read_to_string(&marker).ok().as_deref() != Some(digest.as_str()) {
        fs::create_dir_all(work_dir)?;
        fs::write(&lock, embedded::WORKSPACE_LOCK)
            .with_context(|| format!("writing {}", lock.display()))?;
        fs::write(&marker, &digest)?;
    }
    for (rel, text) in embedded::KERNEL_FILES {
        write_if_changed(&work_dir.join("kernels").join(rel), text)?;
    }
    for v in variants {
        write_variant(work_dir, v)?;
    }
    Ok(())
}

/// Writes the variant crate into the workspace.
pub fn write_variant(work_dir: &Path, v: &VariantSource) -> Result<PathBuf> {
    let dir = work_dir.join("variants").join(&v.package);
    write_if_changed(&dir.join("Cargo.toml"), &v.manifest)?;
    write_if_changed(&dir.join("lib.rs"), &v.source)?;
    Ok(dir)
}

/// A cargo command with a clean environment: no inherited `RUSTFLAGS`,
/// profile or build overrides, incremental compilation off. An empty
/// `CARGO_ENCODED_RUSTFLAGS` takes precedence over `rustflags` from cargo
/// configuration files (found from the current directory and `CARGO_HOME`),
/// so no extra compiler flags reach the variants.
fn cargo_command(opts: &BuildOptions) -> Command {
    let mut cmd = Command::new(&opts.cargo);
    for (key, _) in std::env::vars_os() {
        let Some(k) = key.to_str() else { continue };
        let strip = matches!(
            k,
            "RUSTFLAGS" | "CARGO_ENCODED_RUSTFLAGS" | "RUSTC_WRAPPER" | "RUSTC_WORKSPACE_WRAPPER"
        ) || k.starts_with("CARGO_PROFILE_")
            || k.starts_with("CARGO_BUILD_")
            || (k.starts_with("CARGO_TARGET_") && k != "CARGO_TARGET_DIR");
        if strip {
            cmd.env_remove(k);
        }
    }
    cmd.env("CARGO_TARGET_DIR", &opts.target_dir)
        .env("CARGO_INCREMENTAL", "0")
        .env("CARGO_ENCODED_RUSTFLAGS", "");
    cmd
}

/// Compiles one variant of a workspace made by [`prepare_workspace`] and
/// copies the library into `<work>/lib/`.
pub fn build_variant(opts: &BuildOptions, v: &VariantSource) -> Result<BuiltVariant> {
    let start = Instant::now();
    let mut cmd = cargo_command(opts);
    cmd.arg("build")
        .arg("--release")
        .arg("--quiet")
        .arg("--manifest-path")
        .arg(opts.work_dir.join("Cargo.toml"))
        .arg("-p")
        .arg(&v.package)
        .arg("-j")
        .arg(opts.jobs.max(1).to_string());
    if opts.offline {
        cmd.arg("--offline");
    }
    let out = cmd
        .output()
        .with_context(|| format!("running {}", opts.cargo.display()))?;
    if !out.status.success() {
        // Keep machine paths out of reports.
        let stderr = String::from_utf8_lossy(&out.stderr)
            .replace(&*opts.work_dir.to_string_lossy(), "<work>")
            .replace(&*opts.target_dir.to_string_lossy(), "<target>");
        bail!("building variant {} failed: {}", v.id, stderr.trim());
    }
    let file = format!(
        "{}{}{}",
        std::env::consts::DLL_PREFIX,
        v.lib_name,
        std::env::consts::DLL_SUFFIX
    );
    let built = opts.target_dir.join("release").join(&file);
    let lib_dir = opts.work_dir.join("lib");
    fs::create_dir_all(&lib_dir)?;
    let lib_path = lib_dir.join(&file);
    let bytes = fs::read(&built).with_context(|| format!("reading {}", built.display()))?;
    // Replace rather than overwrite, so a library mapped by an earlier run
    // is never modified in place.
    let tmp = lib_dir.join(format!("{file}.tmp"));
    fs::write(&tmp, &bytes)?;
    fs::rename(&tmp, &lib_path)?;
    Ok(BuiltVariant {
        id: v.id.clone(),
        package: v.package.clone(),
        lib_sha256: format!("sha256:{}", sha256_hex(&bytes)),
        source_sha256: v.source_sha256.clone(),
        lib_path,
        build_ms: u64::try_from(start.elapsed().as_millis()).unwrap_or(u64::MAX),
    })
}

/// Output of `<cargo> -V` run with the build environment, without the build
/// date (see [`strip_build_date`]), or `"unknown"`.
pub fn cargo_version(opts: &BuildOptions) -> String {
    let mut cmd = cargo_command(opts);
    cmd.arg("-V");
    strip_build_date(&command_line(cmd))
}

/// Output of `rustc -V` (or `$RUSTC -V`), without the build date (see
/// [`strip_build_date`]), or `"unknown"`.
pub fn rustc_version() -> String {
    let rustc = std::env::var_os("RUSTC").unwrap_or_else(|| "rustc".into());
    let mut cmd = Command::new(rustc);
    cmd.arg("-V");
    strip_build_date(&command_line(cmd))
}

/// Drops the build date from a tool version string, keeping the commit:
/// `"rustc 1.97.0 (2d8144b78 YYYY-MM-DD)"` becomes `"rustc 1.97.0 (2d8144b78)"`.
/// Reports carry no dates; the commit identifies the toolchain. Other
/// strings are returned unchanged.
pub fn strip_build_date(version: &str) -> String {
    let is_date = |d: &str| {
        let b = d.as_bytes();
        b.len() == 10
            && b.iter().enumerate().all(|(i, c)| match i {
                4 | 7 => *c == b'-',
                _ => c.is_ascii_digit(),
            })
    };
    let is_commit = |h: &str| {
        (7..=40).contains(&h.len()) && h.bytes().all(|c| matches!(c, b'0'..=b'9' | b'a'..=b'f'))
    };
    let Some(open) = version.rfind('(') else {
        return version.to_string();
    };
    let Some(inner) = version[open + 1..].strip_suffix(')') else {
        return version.to_string();
    };
    match inner.split(' ').collect::<Vec<_>>()[..] {
        [commit, date] if is_commit(commit) && is_date(date) => {
            format!("{}({commit})", &version[..open])
        }
        _ => version.to_string(),
    }
}

fn command_line(mut cmd: Command) -> String {
    cmd.output()
        .ok()
        .filter(|o| o.status.success())
        .map(|o| String::from_utf8_lossy(&o.stdout).trim().to_string())
        .filter(|s| !s.is_empty())
        .unwrap_or_else(|| "unknown".into())
}

#[cfg(test)]
mod tests {
    use super::strip_build_date;

    #[test]
    fn version_strings_carry_no_dates() {
        assert_eq!(
            strip_build_date("rustc 1.97.0 (2d8144b78)"),
            "rustc 1.97.0 (2d8144b78)"
        );
        assert_eq!(
            strip_build_date("cargo 1.97.0 (c980f4866)"),
            "cargo 1.97.0 (c980f4866)"
        );
        for unchanged in [
            "unknown",
            "rustc 1.97.0",
            "rustc 1.97.0 (2d8144b78)",
            "rustc 1.97.0 (not-a-commit 0000-00-00)",
            "rustc 1.97.0 (2d8144b78) extra",
        ] {
            assert_eq!(strip_build_date(unchanged), unchanged);
        }
    }
}
