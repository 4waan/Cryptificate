//! Native variant `user` (cryptificate-native codegen v1).
//!
//! Program identity: sha256:f0504a90ebac2de0a5623a741fb228f399487906ac12773c1d1e21a8068d622b
//! Field: GF(2^8), width 4; 15 additions, 4 multiplications.
//!
//! `mix_batch(input, output, column_count)` computes `y = M x` for each of
//! `column_count` columns: 4 bytes per column in row order (byte r is row r), GF(2^8) with polynomial 0x11B.
//! `input` and `output` must not overlap.

#![allow(unused_imports, unused_variables)]

use cryptificate_kernels::gf256::{add, mul, xtime};

const WIDTH: usize = 4;

#[no_mangle]
pub extern "C" fn mix_batch(input: *const u8, output: *mut u8, column_count: usize) {
    let Some(len) = column_count.checked_mul(WIDTH) else {
        return;
    };
    if len == 0 || input.is_null() || output.is_null() {
        return;
    }
    // SAFETY: the caller passes `column_count` columns in each buffer, aligned
    // for `u8`, and the buffers do not overlap.
    let (src, dst) = unsafe {
        (
            core::slice::from_raw_parts(input.cast::<u8>(), len),
            core::slice::from_raw_parts_mut(output.cast::<u8>(), len),
        )
    };
    for (x, y) in src.chunks_exact(WIDTH).zip(dst.chunks_exact_mut(WIDTH)) {
        let r0 = x[0];
        let r1 = x[1];
        let r2 = x[2];
        let r3 = x[3];
        let r4 = add(r0, r1);
        let r5 = add(r4, r2);
        let r6 = add(r5, r3);
        let r7 = add(r0, r2);
        let r8 = xtime(r7);
        let r9 = add(r0, r8);
        let r10 = add(r9, r6);
        let r11 = add(r1, r2);
        let r12 = xtime(r11);
        let r13 = add(r1, r12);
        let r14 = add(r13, r6);
        let r15 = add(r2, r3);
        let r16 = xtime(r15);
        let r17 = add(r2, r16);
        let r18 = add(r17, r6);
        let r19 = add(r3, r0);
        let r20 = xtime(r19);
        let r21 = add(r3, r20);
        let r22 = add(r21, r6);
        y[0] = r10;
        y[1] = r14;
        y[2] = r18;
        y[3] = r22;
    }
}
