# Replaying this bundle

This bundle records a Cryptificate analysis (run `fe06f930a3fbde8c1ef468ec8ce10bef`, inputs `sha256:bebdfa5462bb404ea88ecaba48d6b5d1dfc10bdc052f259a6055f49db9b9668f`).

## Contents

- `inputs.json`: the normalized request.
- `report.json`: claims, witnesses, execution steps and provenance as reported.
- `lean/`: the generated Lean certificate(s) and the checker output (`audit.txt`).
- `toolchain.json`: Lean toolchain, Lake manifest pins, Cargo.lock digest and `rustc -V`.
- `native/` (when a circuit ran natively): generated Rust, the shared kernels, the harness source, native correctness
  results and raw measurements; `native/SOURCES.md` describes the layout.

## Verify

From a Cryptificate checkout prepared with `scripts/setup.sh`:

```sh
npx cryptificate verify <this-bundle>.tar.gz
```

`verify` reads only `inputs.json` and `report.json`. It regenerates the Lean certificate with the installed
engine and templates, runs the installed Lean checker, recomputes the claims and prints a table comparing them
with the claims recorded here. It never runs Lean, Rust or shell code from the bundle. Timings in `report.json`
are historical measurements from the machine that produced the bundle and are reported as such.

## Toolchain

- Lean: `leanprover/lean4:v4.33.1`
- WideTrail: `162c0f8a9e59841032ec5d66874fee31cf3b6298`
- Mathlib: `v4.33.1`
- rustc: `rustc 1.97.0 (2d8144b78)`

Replaying needs the pinned Lean toolchain and the Lake packages listed in `toolchain.json`. On a machine
without them, `scripts/setup.sh` downloads the toolchain (elan), the Lake dependencies and the Mathlib build
cache, which requires network access; it also builds the engine with cargo, which downloads crates unless they
are already vendored or cached. After setup, verification runs offline.
