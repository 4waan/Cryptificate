import Cryptificate

set_option autoImplicit false
set_option maxRecDepth 16000
set_option maxHeartbeats 2000000

namespace CryptificateJob

open Cryptificate

/-- The candidate's `4 × 4` mixing matrix over `GF(2⁸)`, row-major as submitted. -/
def candMatrix : Matrix (Fin 4) (Fin 4) GF256 :=
  gfMat4 0x02 0x03 0x01 0x01 0x01 0x02 0x03 0x01 0x01 0x01 0x02 0x03 0x03 0x01 0x01 0x02

#eval Audit.echoInput "candMatrix" candMatrix

/-- The candidate's row offsets: `out[r][c] = in[r][(c + candOffsets r) mod 4]`, row `r`
rotated left by `candOffsets r`. -/
def candOffsets : Fin 4 → Fin 4 :=
  offsets4 0 1 1 3

#eval Audit.echoInput "candOffsets" candOffsets

/-- The candidate's number of rounds. -/
def candRounds : ℕ := 4

#eval Audit.echoInput "candRounds" candRounds

/-- The candidate's S-box is the AES S-box of FIPS 197, as WideTrail defines it: inversion in
`GF(2⁸)` followed by the affine map with constant `63`. -/
def candSboxTable : GF256 → GF256 := AES.sbox

#eval echoSboxAes "candSboxTable"

/-- Claim `matrix.mds`: every square submatrix of `candMatrix` is nonsingular, so its branch
number is `5`. The kernel evaluates the `69` canonical minors by explicit formulas
(`minors4Ok`), and `isMDS_of_minors4Ok`, proved once for every matrix, turns that into
WideTrail's `IsMDS`. -/
theorem matrix_mds : IsMDS candMatrix :=
  isMDS_of_minors4Ok candMatrix (by decide +kernel)

/-- Claim `offsets.dispersion`, refuted: rows `1` and `2` have the same
offset, so the bytes of one column in those two rows end up in the same column. -/
theorem offsets_not_optimal :
    ¬ DiffusionOptimal (gridCol 4 4) (shiftRowsPerm 4 4 candOffsets) :=
  not_diffusionOptimal_of_offset_collision (1 : Fin 4) 2 (by decide) (by decide)

/-- Claim `sbox.bijective` for the AES S-box, from WideTrail's explicit inverse
`AES.sboxInv`; no table is evaluated. -/
theorem sbox_bijective : Function.Bijective candSboxTable :=
  aes_sbox_bijective

end CryptificateJob
#cryptificate_audit CryptificateJob.matrix_mds
#cryptificate_audit CryptificateJob.offsets_not_optimal
#cryptificate_audit CryptificateJob.sbox_bijective
