//! Native variant `user` (cryptificate-native codegen v1).
//!
//! Program identity: sha256:40876b4d7e0d4448503ae9736b6208da3e8ee4dfb749ec4547168a01a5671ec9
//! Field: GF(2^8), width 4; 0 additions, 0 multiplications.
//!
//! `mix_batch(input, output, column_count)` computes `y = M x` for each of
//! `column_count` columns: 4 bytes per column in row order (byte r is row r), GF(2^8) with polynomial 0x11B.
//! `input` and `output` must not overlap.

#![allow(unused_imports, unused_variables)]

use cryptificate_kernels::gf256::{add, mul, xtime};

const WIDTH: usize = 4;

#[no_mangle]
pub extern "C" fn mix_batch(input: *const u8, output: *mut u8, column_count: usize) {
    let Some(len) = column_count.checked_mul(WIDTH) else {
        return;
    };
    if len == 0 || input.is_null() || output.is_null() {
        return;
    }
    // SAFETY: the caller passes `column_count` columns in each buffer, aligned
    // for `u8`, and the buffers do not overlap.
    let (src, dst) = unsafe {
        (
            core::slice::from_raw_parts(input.cast::<u8>(), len),
            core::slice::from_raw_parts_mut(output.cast::<u8>(), len),
        )
    };
    for (x, y) in src.chunks_exact(WIDTH).zip(dst.chunks_exact_mut(WIDTH)) {
        let r0 = x[0];
        let r1 = x[1];
        let r2 = x[2];
        let r3 = x[3];
        y[0] = r0;
        y[1] = r1;
        y[2] = r2;
        y[3] = r3;
    }
}
