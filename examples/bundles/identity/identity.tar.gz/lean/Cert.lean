import Cryptificate

set_option autoImplicit false
set_option maxRecDepth 16000
set_option maxHeartbeats 2000000

namespace CryptificateJob

open Cryptificate

/-- The candidate's `4 × 4` mixing matrix over `GF(2⁸)`, row-major as submitted. -/
def candMatrix : Matrix (Fin 4) (Fin 4) GF256 :=
  gfMat4 0x01 0x00 0x00 0x00 0x00 0x01 0x00 0x00 0x00 0x00 0x01 0x00 0x00 0x00 0x00 0x01

#eval Audit.echoInput "candMatrix" candMatrix

/-- The candidate's row offsets: `out[r][c] = in[r][(c + candOffsets r) mod 4]`, row `r`
rotated left by `candOffsets r`. -/
def candOffsets : Fin 4 → Fin 4 :=
  offsets4 0 1 2 3

#eval Audit.echoInput "candOffsets" candOffsets

/-- The candidate's number of rounds. -/
def candRounds : ℕ := 4

#eval Audit.echoInput "candRounds" candRounds

/-- The candidate's S-box is the AES S-box of FIPS 197, as WideTrail defines it: inversion in
`GF(2⁸)` followed by the affine map with constant `63`. -/
def candSboxTable : GF256 → GF256 := AES.sbox

#eval echoSboxAes "candSboxTable"

/-- The submitted circuit over `GF(2⁸)`, width four. -/
def candProgram : Circuit.Program GF256 4 :=
  gfProgram4 [] 0 1 2 3

#eval Audit.echoInput "candProgram" candProgram

/-- The branch-number witness: a nonzero column that, together with its image under
`candMatrix`, has fewer than `5` nonzero bytes. -/
def witnessVector : Fin 4 → GF256 :=
  gfVec4 0x01 0x00 0x00 0x00

#eval Audit.echoInput "witnessVector" witnessVector

/-- Claim `matrix.mds`, refuted: `witnessVector` is nonzero, and it and its image under
`candMatrix` have at most `4` nonzero bytes between them, while an MDS matrix forces `5`
(`isMDS_branch_bound`). -/
theorem matrix_not_mds : ¬ IsMDS candMatrix :=
  not_isMDS_of_witness witnessVector (by decide) (by decide)

/-- Claim `offsets.dispersion`: the offsets are pairwise distinct, so row shifting sends the
four bytes of every column to four different columns (Definition 5 of Daemen and Rijmen,
WideTrail's `DiffusionOptimal`). -/
theorem offsets_optimal : DiffusionOptimal (gridCol 4 4) (shiftRowsPerm 4 4 candOffsets) :=
  diffusionOptimal_of_injective (by decide)

/-- Claim `sbox.bijective` for the AES S-box, from WideTrail's explicit inverse
`AES.sboxInv`; no table is evaluated. -/
theorem sbox_bijective : Function.Bijective candSboxTable :=
  aes_sbox_bijective

/-- The submitted circuit is well formed and computes the candidate matrix on every input: its
coefficient matrix, computed once per register, equals `candMatrix`. -/
theorem circuit_equivalence :
    candProgram.WellFormed ∧ ∀ x, candProgram.eval x = candMatrix.mulVec x :=
  Circuit.Program.wellFormed_implements_of_checkEquiv (by decide +kernel)

end CryptificateJob
#cryptificate_audit CryptificateJob.matrix_not_mds
#cryptificate_audit CryptificateJob.offsets_optimal
#cryptificate_audit CryptificateJob.sbox_bijective
#cryptificate_audit CryptificateJob.circuit_equivalence
